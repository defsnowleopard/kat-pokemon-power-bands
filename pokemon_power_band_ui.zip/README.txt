POKÉMON POWER BAND FINDER — LOCAL EXPERIENCE PROTOTYPE

RUN IT
1. Double-click index.html.
2. Search, Power Band facets, Type facets, sorting, quick discovery buttons, and result cards work locally.
3. Artwork loads from the public PokeAPI sprite repository, so images require internet access. The app and data itself are embedded locally.

INTERVIEW POSITIONING
Call this a "local experience prototype" or "intended experience after indexing in Coveo."
Do not represent this local search/facet/sort logic as live Coveo query execution.

30-SECOND DEMO PATH
- Search "Pikachu"
- Clear
- Click "Electric types"
- Click "Show Titans"
- Sort by Power Score high to low
- Point out Power Score = HP + Attack + Defense and the Power Band badge
